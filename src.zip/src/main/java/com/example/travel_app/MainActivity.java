package com.example.travel_app;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView1, recyclerView2;
    RecyclerVerticalView recyclerVerticalView;
    RecyclerHorizontalView recyclerHorizontalView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView1 = findViewById(R.id.recyclerView1);
        recyclerView2 = findViewById(R.id.recyclerView2);

        Vertical_Location[] vertical_location = new Vertical_Location[]{
                new Vertical_Location("Melbourne","Melbourne is the coastal capital of the southeastern Australian state of Victoria.",R.drawable.melbourne),
                new Vertical_Location("Sydney","Sydney, capital of New South Wales and one of Australia's largest cities, is best known for its harbour front Sydney Opera House, with a distinctive sail-like design",R.drawable.sydney),
                new Vertical_Location("Brisbane","Brisbane, capital of Queensland, is a large city on the Brisbane River.",R.drawable.brisbane),
                new Vertical_Location("Gold Coast","The Gold Coast is a metropolitan region south of Brisbane on Australia’s east coast",R.drawable.goldcoast),
                new Vertical_Location("Adelaide","Adelaide is South Australia’s cosmopolitan coastal capital.",R.drawable.adelaide),
                new Vertical_Location("Perth","Perth, capital of Western Australia, sits where the Swan River meets the southwest coast.",R.drawable.perth),
                new Vertical_Location("Tasmania","Tasmania is an island state of Australia. It is located 240 km to the south of the Australian mainland, separated by Bass Strait..",R.drawable.tasmania),
                new Vertical_Location("Cairns","Cairns, considered the gateway to Australia's Great Barrier Reef, is a city in tropical Far North Queensland.",R.drawable.cairns),
                new Vertical_Location("Alice Springs","Alice Springs is a remote town in Australia’s Northern Territory, halfway between Darwin and Adelaide, both 1,500km away.",R.drawable.alicesprings),
        };

        Horizontal_Location[] horizontal_location = new Horizontal_Location[]
        {
                new Horizontal_Location("Melbourne",R.drawable.melbourne),
                new Horizontal_Location("Sydney",R.drawable.sydney),
                new Horizontal_Location("Brisbane",R.drawable.brisbane),
                new Horizontal_Location("Gold Coast",R.drawable.goldcoast),
                new Horizontal_Location("Adelaide",R.drawable.adelaide),
                new Horizontal_Location("Perth",R.drawable.perth),
                new Horizontal_Location("Tasmania",R.drawable.tasmania),
                new Horizontal_Location("Cairns",R.drawable.cairns),
                new Horizontal_Location("Alice Springs",R.drawable.alicesprings),
        };

        recyclerView1.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
        recyclerVerticalView=new RecyclerVerticalView(vertical_location,MainActivity.this);
        recyclerView1.setAdapter(recyclerVerticalView);

        recyclerView2.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        recyclerHorizontalView=new RecyclerHorizontalView(horizontal_location,MainActivity.this);
        recyclerView2.setAdapter(recyclerHorizontalView);
    }
}