package com.example.travel_app;

public class Vertical_Location
{
    private String Location_name;
    private String Location_description;
    private Integer Location_image;

    public Vertical_Location(String Location_name, String Location_description, Integer Location_image)
    {
        this.Location_name = Location_name;
        this.Location_description = Location_description;
        this.Location_image = Location_image;
    }

    public String getLocation_name() {
        return Location_name;
    }

    public void setLocation_name(String location_name) {
        Location_name = location_name;
    }

    public void setLocation_description(String location_description) {
        Location_description = location_description;
    }

    public void setLocation_image(Integer location_image) {
        Location_image = location_image;
    }

    public String getLocation_description() {
        return Location_description;
    }

    public Integer getLocation_image() {
        return Location_image;
    }
}
