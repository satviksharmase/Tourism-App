package com.example.travel_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerVerticalView extends RecyclerView.Adapter<RecyclerVerticalView.ViewHolder>
{
    Vertical_Location[] vertical_location;
    Context context;


    public RecyclerVerticalView(Vertical_Location[] vertical_location, MainActivity activity) {
        this.vertical_location = vertical_location;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.vertical_layout,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        final Vertical_Location vertical_location_list=vertical_location[position];

        holder.imageView1.setImageResource(vertical_location_list.getLocation_image());
        holder.textView3.setText(vertical_location_list.getLocation_name());
        holder.textView4.setText(vertical_location_list.getLocation_description());

        holder.itemView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                if (vertical_location_list.getLocation_name() == "Melbourne") {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    MelbourneFragment melbourneFragment = new MelbourneFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, melbourneFragment).addToBackStack(null).commit();
                }
                else if (vertical_location_list.getLocation_name() == "Sydney") {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    SydneyFragment sydneyFragment = new SydneyFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, sydneyFragment).addToBackStack(null).commit();
                }
                else if (vertical_location_list.getLocation_name() == "Brisbane") {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    BrisbaneFragment brisbaneFragment = new BrisbaneFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, brisbaneFragment).addToBackStack(null).commit();
                }
                else if (vertical_location_list.getLocation_name() == "Gold Coast") {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    GoldCoastFragment goldcoastFragment = new GoldCoastFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, goldcoastFragment).addToBackStack(null).commit();
                }
                else if (vertical_location_list.getLocation_name() == "Adelaide") {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    AdelaideFragment adelaideFragment = new AdelaideFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, adelaideFragment).addToBackStack(null).commit();
                }
                else if (vertical_location_list.getLocation_name() == "Perth") {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    PerthFragment perthFragment = new PerthFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, perthFragment).addToBackStack(null).commit();
                }
                else if (vertical_location_list.getLocation_name() == "Tasmania") {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    TasmaniaFragment tasmaniaFragment = new TasmaniaFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, tasmaniaFragment).addToBackStack(null).commit();
                }
                else if (vertical_location_list.getLocation_name() == "Cairns") {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    CairnsFragment cairnsFragment = new CairnsFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, cairnsFragment).addToBackStack(null).commit();
                }
                else if (vertical_location_list.getLocation_name() == "Alice Springs") {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    AliceSpringsFragment alicespringsFragment = new AliceSpringsFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, alicespringsFragment).addToBackStack(null).commit();
                }
                else {
                    Toast.makeText(context, vertical_location_list.getLocation_name(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return vertical_location.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView textView3,textView4;
        ImageView imageView1;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView3 = itemView.findViewById(R.id.textView3);
            textView4 = itemView.findViewById(R.id.textView4);
            imageView1 = itemView.findViewById(R.id.imageView1);
        }
    }
}
