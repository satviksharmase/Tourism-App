package com.example.travel_app;
public class Horizontal_Location
{
    private String Location_name;
    private Integer Location_image;

    public Horizontal_Location(String Location_name, Integer Location_image)
    {
            this.Location_name =Location_name ;
            this.Location_image = Location_image;
    }

    public void setLocation_name(String location_name) {
        Location_name = location_name;
    }

    public void setLocation_image(Integer location_image) {
        Location_image = location_image;
    }

    public String getLocation_name() {
        return Location_name;
    }

    public Integer getLocation_image() {
        return Location_image;
    }
}
