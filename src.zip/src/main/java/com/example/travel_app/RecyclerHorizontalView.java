package com.example.travel_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerHorizontalView extends RecyclerView.Adapter<RecyclerHorizontalView.ViewHolder>
{
    Horizontal_Location[] horizontal_location;
    Context context;


    public RecyclerHorizontalView(Horizontal_Location[] horizontal_location, MainActivity activity) {
        this.horizontal_location = horizontal_location;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.horizontal_layout,parent,false);
        ViewHolder viewHolder1 = new ViewHolder(view);
        return viewHolder1;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        final Horizontal_Location horizontal_location_list  = horizontal_location[position];

        holder.textView5.setText(horizontal_location_list.getLocation_name());
        holder.imageView2.setImageResource(horizontal_location_list.getLocation_image());

        holder.itemView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(horizontal_location_list.getLocation_name() == "Melbourne")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    MelbourneFragment melbourneFragment = new MelbourneFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, melbourneFragment).addToBackStack(null).commit();
                }
                else if(horizontal_location_list.getLocation_name() == "Sydney")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    SydneyFragment sydneyFragment = new SydneyFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, sydneyFragment).addToBackStack(null).commit();
                }
                else if(horizontal_location_list.getLocation_name() == "Brisbane")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    BrisbaneFragment brisbaneFragment = new BrisbaneFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, brisbaneFragment).addToBackStack(null).commit();
                }
                else if(horizontal_location_list.getLocation_name() == "Gold Coast")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    GoldCoastFragment goldcoastFragment = new GoldCoastFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, goldcoastFragment).addToBackStack(null).commit();
                }
                else if(horizontal_location_list.getLocation_name() == "Adelaide")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    AdelaideFragment adelaideFragment = new AdelaideFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, adelaideFragment).addToBackStack(null).commit();
                }
                else if(horizontal_location_list.getLocation_name() == "Perth")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    PerthFragment perthFragment = new PerthFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, perthFragment).addToBackStack(null).commit();
                }
                else if(horizontal_location_list.getLocation_name() == "Tasmania")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    TasmaniaFragment tasmaniaFragment = new TasmaniaFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, tasmaniaFragment).addToBackStack(null).commit();
                }
                else if(horizontal_location_list.getLocation_name() == "Cairns")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    CairnsFragment cairnsFragment = new CairnsFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, cairnsFragment).addToBackStack(null).commit();
                }
                else if(horizontal_location_list.getLocation_name() == "Alice Springs")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    AliceSpringsFragment alicespringsFragment = new AliceSpringsFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, alicespringsFragment).addToBackStack(null).commit();
                }
                else
                {
                    Toast.makeText(context, horizontal_location_list.getLocation_name(), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    @Override
    public int getItemCount() {
        return horizontal_location.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView textView5;
        ImageView imageView2;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView5 = itemView.findViewById(R.id.textView5);
            imageView2 = itemView.findViewById(R.id.imageView2);
        }
    }
}
